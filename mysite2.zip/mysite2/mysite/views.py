from django.shortcuts import render
import requests
import sys
from subprocess import run,PIPE
def button(request):
    return render(request,'home.html')

def output(request):
     data=requests.get("http://reqres.in/api/users")
     print(data.text)
     data=data.text
     return render(request,'home.html',{'data':data})


def external(request):
    # inp = request.POST.get('param')
    out=run([sys.executable,'F:\\Apeksha\\6th SEM\\Web Technology Lab(WT Lab)\\pip\\mysite2\\test.py'],shell=False,stdout=PIPE)
    #print(out)
    return render(request,'home.html',{'data1': (out.stdout.decode("utf-8"))})


def external1(request):
    out1=run([sys.executable,'F:\\Apeksha\\6th SEM\\Web Technology Lab(WT Lab)\\pip\\mysite2\\test2.py'],shell=False,stdout=PIPE)
    return render(request,'home.html',{'data2': (out1.stdout.decode("utf-8"))})