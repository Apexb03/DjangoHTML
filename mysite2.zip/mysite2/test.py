import sys

output='Hi Hello rah'
print(output, sep='000', end='\n\n')
sys.stdout.write('\n')
sys.stdout.write("File Creation Complete for the given IPO file")

