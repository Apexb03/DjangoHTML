import sys

output1='Welcome'
#conclude= "File Creation Complete for the given IPO file".rstrip()
print(output1)
sys.stdout.write('\n')
sys.stdout.write("The END")

